"""Joint directional-detail processing inside a two-level wavelet expert.

No product, DySample branch, LL-conditioned gate, or spatial HF residual.
The two experiment configurations differ only by retaining the context expert.
"""
import torch
from torch import nn
from torch.nn import functional as F
from model.mobile_mamba import create_wavelet_filter, wavelet_transform, inverse_wavelet_transform
from ablation_variants import build_model as build_reference


class HFJointWT(nn.Module):
    def __init__(self, channels, levels=2):
        super().__init__()
        self.channels = channels
        self.levels = levels
        wt, iwt = create_wavelet_filter('db1', channels, channels, torch.float)
        self.wt_filter = nn.Parameter(wt, requires_grad=False)
        self.iwt_filter = nn.Parameter(iwt, requires_grad=False)
        self.ll_filter = nn.ModuleList([
            nn.Conv2d(channels, channels, 5, padding=2, groups=channels, bias=False)
            for _ in range(levels)
        ])
        self.detail_filter = nn.ModuleList([
            nn.Sequential(
                nn.Conv2d(3 * channels, channels, 1, bias=False),
                nn.GELU(),
                nn.Conv2d(channels, channels, 3, padding=1, groups=channels, bias=False),
                nn.GELU(),
                nn.Conv2d(channels, 3 * channels, 1, bias=False),
            ) for _ in range(levels)
        ])
        self.ll_scale = nn.ParameterList([
            nn.Parameter(torch.full((1, channels, 1, 1), 0.1)) for _ in range(levels)
        ])
        self.detail_scale = nn.ParameterList([
            nn.Parameter(torch.full((1, 3 * channels, 1, 1), 0.1)) for _ in range(levels)
        ])

    def forward(self, x):
        current = x
        low, detail, sizes = [], [], []
        for level in range(self.levels):
            sizes.append(current.shape[-2:])
            h, w = current.shape[-2:]
            current = F.pad(current, (0, w % 2, 0, h % 2))
            bands = wavelet_transform(current, self.wt_filter)
            current = bands[:, :, 0]
            b, c, _, bh, bw = bands.shape
            # Flattening preserves the (channel, LH/HL/HH) ordering.
            raw_detail = bands[:, :, 1:].reshape(b, 3 * c, bh, bw)
            low.append(self.ll_filter[level](current) * self.ll_scale[level])
            mixed = self.detail_filter[level](raw_detail) * self.detail_scale[level]
            detail.append(mixed.reshape(b, c, 3, bh, bw))
        reconstructed = 0
        for level in reversed(range(self.levels)):
            bands = torch.cat([(low[level] + reconstructed).unsqueeze(2), detail[level]], dim=2)
            reconstructed = inverse_wavelet_transform(bands, self.iwt_filter)
            h, w = sizes[level]
            reconstructed = reconstructed[:, :, :h, :w]
        return x + reconstructed


def build_joint_model(cfg):
    from model.mobile_mamba import MobileMambaModule
    net, notes = build_reference(cfg)
    count = 0
    for name, module in net.named_modules():
        if isinstance(module, MobileMambaModule):
            old_hf = module.spacial_moe.experts[0]
            assert getattr(old_hf, 'zone', None) == 'h'
            new_hf = HFJointWT(old_hf.in_channels, levels=2)
            module.spacial_moe.experts[0] = new_hf
            module.global_op[0] = new_hf
            notes.append(dict(module=name, hf='HFJointWT', levels=2,
                              detail='PW3C_to_C_GELU_DW3_GELU_PW_C_to_3C',
                              reconstruction='IWT', input_routing=cfg['input_routing']))
            count += 1
    assert count == 15
    return net, notes


def inspect_model(net, cfg):
    from model.mask import SpatialSparseMoE
    experts = [m for m in net.modules() if isinstance(m, HFJointWT)]
    mixtures = [m for m in net.modules() if isinstance(m, SpatialSparseMoE)]
    expected = 3 if cfg.get('expert_variant') == 'multi_high' else 4
    assert len(experts) == len(mixtures) == 15
    assert all(len(m.experts) == expected and m.input_routing == 'sparse' and m.top_k == 2 for m in mixtures)
    return dict(hf_count=15, moe_count=15, experts_per_moe=expected,
                input_routing='sparse', top_k=2, levels=2,
                parameters=sum(p.numel() for p in net.parameters()))


def cpu_functional_checks():
    torch.set_num_threads(1)
    torch.manual_seed(40)
    m = HFJointWT(8).eval()
    for h, w in [(16, 16), (31, 29)]:
        x = torch.randn(2, 8, h, w, requires_grad=True)
        y = m(x)
        assert y.shape == x.shape and torch.isfinite(y).all()
        changed = x.detach().clone(); changed[1] = torch.randn_like(changed[1])
        assert torch.equal(y[0], m(changed)[0])
        m.zero_grad(); y.square().mean().backward()
        assert all(p.grad is not None and torch.isfinite(p.grad).all() and (p.grad != 0).any()
                   for p in m.detail_filter.parameters())
    z = torch.zeros(2, 8, 17, 15)
    assert torch.equal(m(z), z)
    with torch.no_grad():
        for p in list(m.ll_scale) + list(m.detail_scale): p.zero_()
    x = torch.randn(2, 8, 17, 15)
    assert torch.equal(m(x), x)
    return dict(odd_even_shapes=True, finite=True, sample_independent=True,
                nonzero_finite_detail_gradients=True, zero_input_zero_output=True,
                zero_scales_identity=True, cuda_initialized=torch.cuda.is_initialized())
