from pathlib import Path
import os,json,time,hashlib,subprocess,fcntl,traceback,zipfile,math
R=Path('/root/autodl-tmp/moe_reproduction');E=R/'artifacts/nuaa_hf_joint_v1';PY=R/'env_hf_joint_5090/bin/python'
def atomic(p,obj):
 q=p.with_suffix('.tmp');q.write_text(json.dumps(obj,indent=2,allow_nan=False));q.replace(p)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def frozen():
 for filename in ['contract.json','original_source_hashes.json']:
  for k,v in json.loads((E/filename).read_text()).items():assert sha(R/k)==v,k
def resources(allowed):
 values=subprocess.check_output(['nvidia-smi','--query-gpu=memory.total,memory.free','--format=csv,noheader,nounits'],text=True).strip().split(',')
 apps=subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader,nounits'],text=True).strip()
 assert not ({int(p.strip()) for p in apps.splitlines() if p.strip()}-set(allowed)), 'External GPU process; no new launch'
 workers=[]
 for p in Path('/proc').iterdir():
  if p.name.isdigit():
   try:cmd=(p/'cmdline').read_bytes().replace(b'\0',b' ').decode()
   except (OSError,UnicodeDecodeError):continue
   if 'python' in cmd and ('--mode run' in cmd or '--mode preflight' in cmd):workers.append(int(p.name))
 assert not (set(workers)-set(allowed)), 'Untracked training/preflight worker'
 return float(values[0])/1024,float(values[1])/1024
def spawn(job,mode):
 name=job['run_id'];f=(E/(name+'_'+mode+'.log')).open('a')
 p=subprocess.Popen([str(PY),str(E/'runner.py'),'--mode',mode,'--job',name],cwd=R,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
 f.close();return p
def audit(job):
 import torch
 torch.set_num_threads(1);name=job['run_id'];O=R/'runs/nuaa_hf_joint_v1'/name
 rows=[json.loads(l) for l in (O/'epochs.jsonl').read_text().splitlines()];b=torch.load(O/'best.pt',map_location='cpu',weights_only=False);last=torch.load(O/'last.pt',map_location='cpu',weights_only=False)
 m=json.loads((O/'manifest.json').read_text());bm=json.loads((O/'best_metrics.json').read_text());status=json.loads((O/'status.json').read_text())
 checks=dict(complete=status['status']=='complete',epochs=len(rows)==300,sequence=[r['epoch'] for r in rows]==list(range(300)),finite_rows=all(all(math.isfinite(v) for v in r.values() if isinstance(v,(int,float))) for r in rows),fixed_lr=all(r['lr']==r['next_lr']==.05 for r in rows),last_epoch=last['epoch']==299,config=m['job']==job and b['configuration']==job['configuration'],best_epoch=b['epoch']==bm['epoch']==max(rows,key=lambda r:r['IoU'])['epoch'],same_four_metrics=all(b['metrics'][k]==bm[k]==rows[b['epoch']][k] for k in ['IoU','nIoU','Pd','Fa']),finite_weights=all(torch.isfinite(v).all().item() for model in [b['model'],last['model']] for v in model.values() if v.is_floating_point()),sources=b['source_sha256']==last['source_sha256']==m['source_sha256'],config_hash=last['config_sha256']==m['config_sha256']==hashlib.sha256(json.dumps(job['configuration'],sort_keys=True).encode()).hexdigest(),contract=True,original_sources=True)
 frozen()
 for split in ['train','test']:checks[split+'_split']=sha(R/'data/NUAA-SIRST/50_50'/(split+'.txt'))==m[split+'_ids_sha256']
 assert all(checks.values()),checks
 result=dict(run_id=name,checks=checks,best_epoch_one_based=b['epoch']+1,metrics=b['metrics'],best_sha256=sha(O/'best.pt'),last_sha256=sha(O/'last.pt'),finished=status['finished'])
 atomic(E/(name+'_audit.json'),result);archive=E/(name+'_completed.zip')
 with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=5) as z:
  for p in O.iterdir():
   if p.is_file():z.write(p,str(p.relative_to(R)))
  for p in E.rglob('*'):
   if p.is_file() and p.suffix in ['.py','.json'] and '__pycache__' not in str(p) and not p.name.endswith('_backup_receipt.json'):z.write(p,str(p.relative_to(R)))
 atomic(E/(name+'_backup_receipt.json'),dict(archive=str(archive),bytes=archive.stat().st_size,sha256=sha(archive),**result))
 return result
if __name__=='__main__':
 lock=(E/'controller.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 jobs=json.loads((E/'matrix.json').read_text())['runs'];active={};done={};reservations={}
 try:
  frozen();total,free=resources([]);assert free>22
  for job in jobs:
   for mode in ['cpu','preflight']:
    frozen();resources([]);p=spawn(job,mode)
    atomic(E/'controller_status.json',dict(phase=mode,job=job['run_id'],worker_pid=p.pid,pid=os.getpid(),updated=time.strftime('%Y-%m-%d %H:%M:%S')))
    assert p.wait()==0,(job['run_id'],mode,'failed; no training launch')
   pf=json.loads((E/(job['run_id']+'_preflight.json')).read_text());assert pf['status']=='passed';reservations[job['run_id']]=pf['reserved_gib']*1.1+.5
  pending=list(jobs)
  while pending or active:
   frozen()
   for name,item in list(active.items()):
    code=item['process'].poll()
    if code is not None:
     assert code==0,(name,'worker failed')
     done[name]=audit(item['job']);del active[name]
   allowed=[item['process'].pid for item in active.values()]
   total,free=resources(allowed)
   while pending and len(active)<2:
    job=pending[0];reserve=reservations[job['run_id']]
    if reserve+sum(reservations[n] for n in active)>total-1.5 or reserve>free-1.5:break
    p=spawn(job,'run');active[job['run_id']]=dict(job=job,process=p);pending.pop(0);free-=reserve
   atomic(E/'controller_status.json',dict(phase='run' if active else ('waiting_capacity' if pending else 'complete_audited_remote'),pid=os.getpid(),active={n:dict(pid=v['process'].pid,reservation_gib=reservations[n]) for n,v in active.items()},pending=[j['run_id'] for j in pending],completed=list(done),reservations=reservations,updated=time.strftime('%Y-%m-%d %H:%M:%S')))
   if pending or active:time.sleep(15)
 except BaseException:
  atomic(E/'controller_status.json',dict(phase='error',pid=os.getpid(),traceback=traceback.format_exc(),active={n:v['process'].pid for n,v in active.items()},updated=time.strftime('%Y-%m-%d %H:%M:%S')));raise
