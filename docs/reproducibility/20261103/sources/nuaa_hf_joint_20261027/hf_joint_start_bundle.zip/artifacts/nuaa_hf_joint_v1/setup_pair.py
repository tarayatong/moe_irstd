from pathlib import Path
import ast,hashlib,json,shutil
R=Path('/root/autodl-tmp/moe_reproduction');E=R/'artifacts/nuaa_hf_joint_v1'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,obj):p.write_text(json.dumps(obj,indent=2,allow_nan=False))
assert not E.exists(),'Refusing to overwrite new experiment'
# Verify prior completed experiments before creating this isolated version.
S=R/'artifacts/nuaa_hf_triple_product_v1'
for k,v in json.loads((S/'original_source_hashes.json').read_text()).items():assert sha(R/k)==v,k
for k,v in json.loads((S/'contract.json').read_text()).items():assert sha(R/k)==v,k
E.mkdir();(E/'support').mkdir()
shutil.copytree(R/'code/experiment_runtime',E/'runtime',ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
shutil.copy2(R/'artifacts/ablation_variants.py',E/'support/ablation_variants.py')
shutil.copy2(S/'original_source_hashes.json',E/'original_source_hashes.json')
for src,dest in [('hf_joint.py',E/'support/hf_joint.py'),('pair_controller.py',E/'controller.py'),('setup_pair.py',E/'setup_pair.py')]:shutil.copy2(Path('/tmp')/src,dest)
base=json.loads((R/'artifacts/nuaa_fixed005_v2_matrix.json').read_text())['runs'][0]['configuration']
jobs=[]
for suffix,variant in [('spatial_identity_hf','multi_high'),('complete',None)]:
 c=base.copy();c['hf_design']='joint_directional_detail_wt2_v1'
 if variant:c['expert_variant']=variant
 jobs.append(dict(run_id='NUAA-SIRST_hf_joint_'+suffix+'_sparse300',configuration=c))
save(E/'matrix.json',dict(runs=jobs))
s=(S/'runner.py').read_text().split('\ndef inspect_model(')[0]
s=s.replace('nuaa_hf_triple_product_v1','nuaa_hf_joint_v1')
s=s.replace('from ablation_variants import build_model,auxiliary_loss','from ablation_variants import auxiliary_loss\nfrom hf_joint import build_joint_model as build_model, inspect_model, cpu_functional_checks, HFJointWT')
s+='''
def checked_preflight(job):
    reference=build_model;handles=[];stats={}
    def checked(c):
        net,notes=reference(c);inspect_model(net,c)
        for name,m in net.named_modules():
            if isinstance(m,HFJointWT):
                stats[name]={'calls':0,'backward_calls':0,'nonzero_gradient':False}
                def check(mod,inputs,output,n=name):
                    assert output.shape==inputs[0].shape and torch.isfinite(output).all()
                    rec=stats[n];rec['calls']+=1
                    if output.requires_grad:
                        def gradient(g):
                            assert torch.isfinite(g).all();rec['backward_calls']+=1;rec['nonzero_gradient'] |= bool((g!=0).any())
                        output.register_hook(gradient)
                handles.append(m.register_forward_hook(check))
        return net,notes
    globals()['build_model']=checked
    try:result=preflight(job)
    finally:
        globals()['build_model']=reference
        for h in handles:h.remove()
    assert len(stats)==15 and all(v['calls']>=4 and v['backward_calls']>=4 and v['nonzero_gradient'] for v in stats.values())
    result['hf_checks']=stats;result['finite_parameter_gradients']=True
    return result

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--mode',required=True,choices=['cpu','preflight','run']);p.add_argument('--job',required=True);a=p.parse_args()
    job=next(j for j in json.loads((EXP/'matrix.json').read_text())['runs'] if j['run_id']==a.job)
    if a.mode=='cpu':
        result=cpu_functional_checks();net,notes=build_model(job['configuration']);result.update(inspect_model(net,job['configuration']));atomic_json(EXP/(a.job+'_cpu.json'),result)
    elif a.mode=='preflight':atomic_json(EXP/(a.job+'_preflight.json'),checked_preflight(job))
    else:run(job)
'''
(E/'runner.py').write_text(s)
oldtree=ast.parse((S/'runner.py').read_text());newtree=ast.parse(s)
for name in ['seed_all','Metrics','evaluate','loaders','preflight']:
 a=next(n for n in oldtree.body if getattr(n,'name',None)==name);b=next(n for n in newtree.body if getattr(n,'name',None)==name)
 assert ast.dump(a,include_attributes=False)==ast.dump(b,include_attributes=False),name
files=list((E/'runtime').rglob('*.py'))+list((E/'support').glob('*.py'))+[E/'runner.py',E/'controller.py',E/'setup_pair.py',E/'matrix.json']
save(E/'contract.json',{str(p.relative_to(R)):sha(p) for p in files})
save(E/'setup_receipt.json',dict(jobs=jobs,reference_configuration=base,ast_unchanged=['seed_all','Metrics','evaluate','loaders','preflight'],frozen_files=len(files),details='two-level DWT; LL depthwise5; joint HF PW3C-C/GELU/DW3/GELU/PW C-3C; linear signed output; scales0.1; IWT reconstruction; no extra spatial HF residual/DySample/product/LL gate'))
import subprocess,sys,importlib.metadata as metadata
save(E/'environment_receipt.json',dict(python=sys.version,executable=sys.executable,packages={n:metadata.version(n) for n in ['torch','torchvision','numpy','scipy','scikit-image','pillow','timm','PyWavelets','einops']},gpu=subprocess.getoutput('nvidia-smi --query-gpu=name,driver_version,memory.total --format=csv,noheader'),comparison_limit='Migrated from RTX4090D/torch2.5cu118 to RTX5090/torch2.8cu128 because old CUDA kernels cannot run on sm120; do not attribute all old/new differences exclusively to architecture.'))
print('PAIR_SETUP_OK',len(files))
