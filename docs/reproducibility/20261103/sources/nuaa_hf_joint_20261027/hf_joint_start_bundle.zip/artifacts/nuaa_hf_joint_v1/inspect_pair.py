"""Read-only model/job inspection; writes only a monitoring snapshot."""
from pathlib import Path
import json,hashlib,math,subprocess,base64,time
R=Path('/root/autodl-tmp/moe_reproduction');E=R/'artifacts/nuaa_hf_joint_v1'
def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
jobs=read(E/'matrix.json')['runs'];report={}
for job in jobs:
 name=job['run_id'];O=R/'runs/nuaa_hf_joint_v1'/name
 rows=[json.loads(l) for l in (O/'epochs.jsonl').read_text().splitlines()] if (O/'epochs.jsonl').exists() else []
 status=read(O/'status.json') if (O/'status.json').exists() else {'status':'pending'}
 checks=dict(sequence=[r['epoch'] for r in rows]==list(range(len(rows))),finite=all(all(math.isfinite(v) for v in r.values() if isinstance(v,(int,float))) for r in rows),fixed_lr=all(r['lr']==r['next_lr']==.05 for r in rows))
 best=max(rows,key=lambda r:r['IoU']) if rows else None
 if best:
  bm=read(O/'best_metrics.json');checks['same_best_epoch_four_metrics']=bm['epoch']==best['epoch'] and all(bm[k]==best[k] for k in ['IoU','nIoU','Pd','Fa'])
 item=dict(configuration=job['configuration'],status=status,completed_epochs=len(rows),best=best,checks=checks,files={n:dict(bytes=(O/n).stat().st_size,mtime=(O/n).stat().st_mtime) for n in ['epochs.jsonl','best.pt','last.pt','best_metrics.json'] if (O/n).exists()})
 for suffix in ['_cpu.json','_preflight.json','_audit.json','_backup_receipt.json']:
  p=E/(name+suffix)
  if p.exists():item[suffix]=read(p)
 report[name]=item
workers=[]
for p in Path('/proc').iterdir():
 if p.name.isdigit():
  try:cmd=(p/'cmdline').read_bytes().replace(b'\0',b' ').decode()
  except (OSError,UnicodeDecodeError):continue
  if 'python' in cmd and ('nuaa_hf_joint_v1/runner.py' in cmd or 'nuaa_hf_joint_v1/controller.py' in cmd):workers.append(dict(pid=int(p.name),cmd=cmd))
checks={n:all(sha(R/k)==v for k,v in read(E/n).items()) for n in ['contract.json','original_source_hashes.json']}
snapshot=dict(checked_at=time.strftime('%Y-%m-%d %H:%M:%S')+'+08:00',jobs=report,source_checks=checks,controller=read(E/'controller_status.json') if (E/'controller_status.json').exists() else None,workers=workers,gpu=subprocess.getoutput('nvidia-smi --query-gpu=name,memory.total,memory.free,utilization.gpu --format=csv,noheader'),gpu_processes=subprocess.getoutput('nvidia-smi --query-compute-apps=pid,used_memory --format=csv,noheader'),disk=subprocess.getoutput('df -h /root/autodl-tmp'))
(E/'monitor_latest.json').write_text(json.dumps(snapshot,indent=2,allow_nan=False))
encoded=base64.b64encode(json.dumps(snapshot).encode()).decode();print('SNAP_BEGIN')
for i in range(0,len(encoded),60):print('DATA '+encoded[i:i+60])
print('SNAP_END')
