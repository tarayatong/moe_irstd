"""Independent tail scheduler; executes the unchanged V2 worker only.

No torch import and no GPU probe/worker before the original 29-run barrier.
"""
import fcntl
import hashlib
import json
import math
import os
from pathlib import Path
import subprocess
import sys
import time
import traceback

ROOT = Path('/root/autodl-tmp/moe_reproduction')
ART = ROOT / 'artifacts'
OUT = ROOT / 'runs/nuaa_fixed005_300'
MATRIX = ART / 'nuaa_fullroute_tail_v1_matrix.json'
CONTRACT = ART / 'nuaa_fullroute_tail_v1_contract.json'
STATUS = ART / 'nuaa_fullroute_tail_v1_queue_status.json'
RESULTS = ART / 'nuaa_fullroute_tail_v1_results.json'
WORKER = ART / 'run_nuaa_fixed005_v2.py'
JOURNAL = ROOT / 'logs/nuaa_fullroute_tail_v1_events.jsonl'
POLL = 15


def atomic(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + '.tmp')
    tmp.write_text(json.dumps(value, indent=2, allow_nan=False))
    tmp.replace(path)


def read(path, default=None):
    return json.loads(path.read_text()) if path.exists() else default


def event(kind, **fields):
    with JOURNAL.open('a') as f:
        f.write(json.dumps(dict(time=time.strftime('%Y-%m-%d %H:%M:%S'), event=kind, **fields)) + '\n')
    print(kind, json.dumps(fields), flush=True)


def live_runners():
    found = []
    for proc in Path('/proc').iterdir():
        if not proc.name.isdigit():
            continue
        try:
            args = [s.decode() for s in (proc / 'cmdline').read_bytes().split(b'\0') if s]
            state = (proc / 'status').read_text().split('State:')[1].lstrip()[0]
        except (FileNotFoundError, PermissionError, ProcessLookupError):
            continue
        scripts = [a for a in args if Path(a).name in (
            'run_nuaa_fixed005_v1.py', 'run_nuaa_fixed005_v2.py',
            'run_nuaa_fixed005_v3.py', 'run_nuaa_fixed005.py')]
        if state == 'Z' or not scripts or '--mode' not in args:
            continue
        mode = args[args.index('--mode') + 1]
        job = args[args.index('--job') + 1] if '--job' in args else None
        found.append(dict(pid=int(proc.name), mode=mode, job=job, args=args))
    return found


def predecessors_ready(states, runners):
    return (all(s and s.get('status') == 'complete' and s.get('epochs') == 300
                for s in states.values()) and not runners)


def can_admit(need, reservations, free_gib, total_gib, runner_count, foreign_gpu):
    return (not foreign_gpu and runner_count < 2 and
            sum(reservations) + need <= total_gib - 1.5 and
            need + 0.5 <= free_gib)


def gpu():
    values = subprocess.check_output([
        'nvidia-smi', '--query-gpu=memory.total,memory.free,utilization.gpu',
        '--format=csv,noheader,nounits'], text=True).strip().split(',')
    total, free, utilization = [float(v.strip()) for v in values]
    pids = subprocess.check_output([
        'nvidia-smi', '--query-compute-apps=pid', '--format=csv,noheader,nounits'],
        text=True).strip().splitlines()
    return total / 1024, free / 1024, utilization, {int(p.strip()) for p in pids if p.strip().isdigit()}


def verify_contract(contract):
    for rel, expected in contract['sha256'].items():
        assert hashlib.sha256((ROOT / rel).read_bytes()).hexdigest() == expected, 'Frozen file changed: ' + rel


def main():
    lock = (ART / 'nuaa_fullroute_tail_v1_queue.lock').open('a+')
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    contract = read(CONTRACT)
    matrix = read(MATRIX)
    jobs = matrix['runs']
    assert len(jobs) == 2
    verify_contract(contract)
    active = {}
    phase = 'waiting_original_29'
    current_preflight = None

    def publish(detail=None):
        pending, completed, failed = [], [], []
        results = []
        for job in jobs:
            name = job['run_id']
            s = read(OUT / name / 'status.json', {})
            if s.get('status') == 'complete':
                completed.append(name)
                m = read(OUT / name / 'best_metrics.json')
                results.append(dict(run_id=name, protocol='constant005_300_full_input',
                                    best_epoch_one_based=m['epoch'] + 1,
                                    metrics={k: m[k] for k in ['IoU', 'nIoU', 'Pd', 'Fa']}))
            elif s.get('status') == 'failed':
                failed.append(name)
            elif name not in active:
                pending.append(name)
        atomic(RESULTS, results)
        atomic(STATUS, dict(phase=phase, controller_pid=os.getpid(), updated=time.strftime('%Y-%m-%d %H:%M:%S'),
                           predecessors_total=29, active={n: dict(pid=v[0].pid, reservation_gib=v[2]) for n, v in active.items()},
                           preflight=current_preflight, pending=pending, completed=completed,
                           failed=failed, detail=detail, matrix=str(MATRIX), worker=str(WORKER)))

    try:
        event('SCHEDULED', order=[j['run_id'] for j in jobs], after_original_runs=29)
        while True:
            states = {n: read(OUT / n / 'status.json') for n in contract['predecessor_ids']}
            runners = live_runners()
            if predecessors_ready(states, runners):
                break
            publish(dict(predecessors_completed=sum(bool(s and s.get('status') == 'complete') for s in states.values()),
                         remaining_predecessors=[n for n, s in states.items() if not s or s.get('status') != 'complete'],
                         live_runners=runners))
            time.sleep(POLL)

        verify_contract(contract)
        event('ORIGINAL_29_FINISHED')
        # Profile the exact full-input configurations on an idle GPU before any new training.
        profiles = {}
        for job in jobs:
            name = job['run_id']
            existing = read(OUT / name / 'status.json', {})
            if existing.get('status') == 'complete':
                continue
            assert not existing, 'Existing incomplete new run requires explicit inspection: ' + name
            phase = 'waiting_idle_gpu_for_preflight'
            while True:
                total, free, util, gpu_pids = gpu()
                if not live_runners() and not gpu_pids and free >= total - 1.5:
                    break
                publish(dict(job=name, gpu_free_gib=free, gpu_pids=sorted(gpu_pids)))
                time.sleep(POLL)
            verify_contract(contract)
            phase = 'preflight'
            log = (ROOT / 'logs' / ('nuaa_fullroute_preflight_' + name + '.log')).open('a', buffering=1)
            process = subprocess.Popen([sys.executable, str(WORKER), '--mode', 'preflight',
                                        '--matrix', str(MATRIX), '--job', name], cwd=ROOT,
                                       stdout=log, stderr=log,
                                       env=dict(os.environ, OMP_NUM_THREADS='4', MKL_NUM_THREADS='4', PYTHONUNBUFFERED='1'))
            current_preflight = dict(job=name, pid=process.pid)
            event('PREFLIGHT_START', **current_preflight)
            while process.poll() is None:
                publish()
                time.sleep(POLL)
            log.close()
            current_preflight = None
            pf = read(ART / 'nuaa_preflight' / (name + '.json'), {})
            assert process.returncode == 0 and pf.get('status') == 'passed', 'Preflight failed: ' + name
            need = float(pf['reserved_gib']) * 1.25 + 1.0
            assert math.isfinite(need) and need > 0 and need <= total - 1.5, 'Capacity insufficient: ' + name
            profiles[name] = need
            event('PREFLIGHT_PASSED', job=name, reservation_gib=need)

        pending = [j for j in jobs if read(OUT / j['run_id'] / 'status.json', {}).get('status') != 'complete']
        phase = 'training'
        failure = None
        while pending or active:
            for name, (process, log, need) in list(active.items()):
                if process.poll() is None:
                    continue
                log.close()
                s = read(OUT / name / 'status.json', {})
                if process.returncode != 0 or s.get('status') != 'complete':
                    failure = 'Worker did not complete: ' + name
                event('WORKER_EXIT', job=name, pid=process.pid, code=process.returncode, status=s)
                del active[name]
            if not failure:
                for job in list(pending):
                    name = job['run_id']
                    verify_contract(contract)
                    runners = live_runners()
                    total, free, util, gpu_pids = gpu()
                    owned = {p.pid for p, _, _ in active.values()}
                    foreign = any(p['pid'] not in owned for p in runners) or bool(gpu_pids - owned)
                    if not can_admit(profiles[name], [v[2] for v in active.values()], free, total, max(len(runners), len(active)), foreign):
                        break
                    out = OUT / name
                    assert not (out / 'status.json').exists(), 'Unexpected existing run: ' + name
                    out.mkdir(parents=True, exist_ok=True)
                    log = (out / 'console.log').open('a', buffering=1)
                    process = subprocess.Popen([sys.executable, str(WORKER), '--mode', 'run', '--matrix', str(MATRIX), '--job', name],
                                               cwd=ROOT, stdout=log, stderr=log,
                                               env=dict(os.environ, OMP_NUM_THREADS='4', MKL_NUM_THREADS='4', PYTHONUNBUFFERED='1'))
                    active[name] = (process, log, profiles[name])
                    pending.remove(job)
                    event('START', job=name, pid=process.pid, input_routing='full')
            if failure and not active:
                raise RuntimeError(failure)
            publish(dict(error=failure) if failure else None)
            if pending or active:
                time.sleep(POLL)
        phase = 'complete'
        publish()
        event('FULLROUTE_TAIL_FINISHED')
    except BaseException as error:
        phase = 'halted_requires_inspection'
        publish(dict(error=repr(error), traceback=traceback.format_exc()))
        event('HALTED', error=repr(error))
        raise


if __name__ == '__main__':
    main()
