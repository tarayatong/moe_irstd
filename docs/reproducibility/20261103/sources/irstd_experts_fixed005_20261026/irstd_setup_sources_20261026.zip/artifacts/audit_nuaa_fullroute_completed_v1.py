"""Read-only completed-run verification and separate backup packaging."""
from pathlib import Path
import argparse,datetime,hashlib,json,math,torch,zipfile
ROOT=Path('/root/autodl-tmp/moe_reproduction')
def main():
 ap=argparse.ArgumentParser();ap.add_argument('run_id');args=ap.parse_args()
 jobs=json.loads((ROOT/'artifacts/nuaa_fullroute_tail_v1_matrix.json').read_text())['runs']
 job=next(j for j in jobs if j['run_id']==args.run_id);name=job['run_id'];p=ROOT/'runs/nuaa_fixed005_300'/name;torch.set_num_threads(2)
 st=json.loads((p/'status.json').read_text());bm=json.loads((p/'best_metrics.json').read_text());m=json.loads((p/'manifest.json').read_text());rows=[json.loads(s) for s in (p/'epochs.jsonl').read_text().splitlines()];best=torch.load(p/'best.pt',map_location='cpu',weights_only=False);last=torch.load(p/'last.pt',map_location='cpu',weights_only=False);row=next(x for x in rows if x['epoch']==bm['epoch']);keys=['IoU','nIoU','Pd','Fa'];c=job['configuration']
 checks=dict(full_input=c['input_routing']=='full',complete=st['status']=='complete',all_epochs=len(rows)==c['epochs'] and [x['epoch'] for x in rows]==list(range(c['epochs'])),last_epoch=last['epoch']==c['epochs']-1,same_epoch=bm['epoch']==best['epoch']==st['best_epoch']==last['best_epoch'],same_configuration=bm['configuration']==best['configuration']==m['job']['configuration']==c,four_metrics=all(bm[k]==best['metrics'][k]==row[k] for k in keys),best_iou=bm['IoU']==max(x['IoU'] for x in rows)==last['best_iou'],finite_rows=all(math.isfinite(x[k]) for x in rows for k in ['train_loss','test_loss']+keys),constant_lr=all(x['lr']==x['next_lr']==.05 for x in rows),checkpoint_lr=last['optimizer']['param_groups'][0]['lr']==.05,config_hash=last['config_sha256']==m['config_sha256']==hashlib.sha256(json.dumps(c,sort_keys=True).encode()).hexdigest(),source_hash=last['source_sha256']==m['source_sha256']==best['source_sha256'] and all(hashlib.sha256((ROOT/f).read_bytes()).hexdigest()==h for f,h in last['source_sha256'].items()))
 assert all(checks.values()),checks
 record=dict(run_id=name,protocol='constant005_300',input_routing='full',group=job['group'],finished=st['finished'],verified_at=datetime.datetime.now().astimezone().isoformat(),best_epoch_one_based=bm['epoch']+1,metrics={k:bm[k] for k in keys},display_metrics={k:round(bm[k]*(1e6 if k=='Fa' else 100),2) for k in keys},checks=checks,best_pt_sha256=hashlib.sha256((p/'best.pt').read_bytes()).hexdigest())
 audit=ROOT/'artifacts/completed_audits'/f'{name}.json';audit.parent.mkdir(parents=True,exist_ok=True);audit.write_text(json.dumps(record,indent=2,allow_nan=False));print('VERIFIED',json.dumps(record),flush=True)
 backup=ROOT/'artifacts'/f'nuaa_{name}_completed_20261024.zip'
 with zipfile.ZipFile(backup,'w',zipfile.ZIP_DEFLATED,compresslevel=1) as z:
  for f in [audit,ROOT/'artifacts/nuaa_fullroute_tail_v1_matrix.json',ROOT/'artifacts/nuaa_fullroute_tail_v1_contract.json',ROOT/'artifacts/nuaa_fullroute_tail_v1_queue_status.json',ROOT/'artifacts/nuaa_fullroute_tail_v1_results.json']:
   z.write(f,str(f.relative_to(ROOT)))
  for fn in ['best.pt','best_metrics.json','epochs.jsonl','manifest.json','status.json','console.log']:
   f=p/fn;z.write(f,str(f.relative_to(ROOT)))
 h=hashlib.sha256(backup.read_bytes()).hexdigest();receipt=dict(run_id=name,archive=backup.name,bytes=backup.stat().st_size,sha256=h)
 (ROOT/'artifacts/completed_audits'/f'{name}_backup_receipt.json').write_text(json.dumps(receipt,indent=2));print('BACKUP',backup.name,backup.stat().st_size,flush=True);print('SHA_FIRST',h[:32]);print('SHA_LAST',h[32:],flush=True)
if __name__=='__main__':main()
