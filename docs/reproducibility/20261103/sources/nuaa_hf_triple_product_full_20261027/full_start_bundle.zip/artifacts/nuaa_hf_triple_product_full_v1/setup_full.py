from pathlib import Path
import hashlib,json,shutil,ast
R=Path('/root/autodl-tmp/moe_reproduction')
S=R/'artifacts/nuaa_hf_triple_product_v1';E=R/'artifacts/nuaa_hf_triple_product_full_v1'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,d):p.write_text(json.dumps(d,indent=2,allow_nan=False))
assert not E.exists(),'Refusing to overwrite experiment'
assert json.loads((S/'controller_status.json').read_text())['phase']=='complete_audited_remote'
for k,v in json.loads((S/'contract.json').read_text()).items():assert sha(R/k)==v,k
for k,v in json.loads((S/'original_source_hashes.json').read_text()).items():assert sha(R/k)==v,k
E.mkdir()
for n in ['runtime','support']:shutil.copytree(S/n,E/n,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
for n in ['original_source_hashes.json','model_change.diff']:shutil.copy2(S/n,E/n)
old=json.loads((S/'matrix.json').read_text())['runs'][0];job=json.loads(json.dumps(old));job['configuration']['input_routing']='full';job['run_id']='NUAA-SIRST_hf_triple_product_full_control300'
assert {k:(old['configuration'][k],v) for k,v in job['configuration'].items() if v!=old['configuration'][k]}=={'input_routing':('sparse','full')}
write(E/'matrix.json',dict(runs=[job],reference=old['run_id'],config_only_difference='input_routing sparse -> full'))
for name in ['runner.py','controller.py']:
 s=(S/name).read_text().replace('nuaa_hf_triple_product_v1','nuaa_hf_triple_product_full_v1')
 if name=='runner.py':
  s=s.replace("m.input_routing=='sparse'", "m.input_routing=='full'").replace("input_routing='sparse'", "input_routing='full'")
 else:s=s.replace('NUAA_hf_triple_product_sparse_completed.zip','NUAA_hf_triple_product_full_completed.zip')
 (E/name).write_text(s)
# All actual model/source files are byte-identical to the completed sparse product version.
for folder in ['runtime','support']:
 for p in (S/folder).rglob('*.py'):assert sha(p)==sha(E/p.relative_to(S))
a=ast.parse((S/'runner.py').read_text());b=ast.parse((E/'runner.py').read_text())
for name in ['seed_all','Metrics','evaluate','loaders','preflight','extended_preflight']:
 x=next(n for n in a.body if getattr(n,'name',None)==name);y=next(n for n in b.body if getattr(n,'name',None)==name)
 assert ast.dump(x,include_attributes=False)==ast.dump(y,include_attributes=False),name
shutil.copy2('/tmp/setup_full.py',E/'setup_full.py')
files=list((E/'runtime').rglob('*.py'))+list((E/'support').glob('*.py'))+[E/'runner.py',E/'controller.py',E/'setup_full.py',E/'matrix.json']
write(E/'contract.json',{str(p.relative_to(R)):sha(p) for p in files})
write(E/'setup_receipt.json',dict(job=job,sparse_reference=old,configuration_differences={'input_routing':['sparse','full']},model_runtime_identical=True,ast_verified=['seed_all','Metrics','evaluate','loaders','preflight','extended_preflight'],original_experiments_unchanged=True,contract_files=len(files)))
print('FULL_SETUP_OK',len(files),flush=True)
