from pathlib import Path
import ast,hashlib,json,shutil,difflib
R=Path('/root/autodl-tmp/moe_reproduction')
E=R/'artifacts/nuaa_hf_triple_product_v1'
assert not E.exists(), 'Refusing to overwrite experiment'
E.mkdir()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,d):p.write_text(json.dumps(d,indent=2,allow_nan=False))
baseline=json.loads((R/'runs/nuaa_fixed005_300/NUAA-SIRST_control300/manifest.json').read_text())
for k,v in baseline['source_sha256'].items():
 if k.startswith('code/experiment_runtime/') or k=='artifacts/ablation_variants.py':assert sha(R/k)==v,k
original={str(p.relative_to(R)):sha(p) for p in (R/'code/experiment_runtime').rglob('*.py')}
original.update({str(p.relative_to(R)):sha(p) for p in (R/'artifacts').glob('*.py')})
save(E/'original_source_hashes.json',original)
shutil.copytree(R/'code/experiment_runtime',E/'runtime',ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
(E/'support').mkdir()
shutil.copy2(R/'artifacts/ablation_variants.py',E/'support/ablation_variants.py')
f=E/'runtime/model/mobile_mamba.py';before=f.read_text();s=before
old='''        self.hconv = nn.Sequential(
            DySample(in_channels*3, scale=2),
            DWConv2d_BN_ReLU(in_channels*3, in_channels, kernel_size=1),
        )'''
new='''        # Product HF branch: C signed channels, no display normalization/clipping.
        hf_channels = in_channels if self.zone == 'h' else in_channels * 3
        self.hconv = nn.Sequential(
            DySample(hf_channels, scale=2),
            DWConv2d_BN_ReLU(hf_channels, in_channels, kernel_size=1),
        )'''
assert s.count(old)==1;s=s.replace(old,new)
old='new_x_h = self.hconv(x_h.reshape(shape_x[0], shape_x[1] * 3, shape_x[3], shape_x[4]))'
new='new_x_h = self.hconv(x_h[:, :, 0] * x_h[:, :, 1] * x_h[:, :, 2])'
assert s.count(old)==1;s=s.replace(old,new);f.write_text(s)
(E/'model_change.diff').write_text(''.join(difflib.unified_diff(before.splitlines(True),s.splitlines(True),fromfile='baseline/mobile_mamba.py',tofile='product/mobile_mamba.py')))
assert all(sha(p)==original[str((R/'code/experiment_runtime'/p.relative_to(E/'runtime')).relative_to(R))] for p in (E/'runtime').rglob('*.py') if p!=f)
c=baseline['job']['configuration'].copy()
ref=json.loads((R/'artifacts/nuaa_fixed005_v2_matrix.json').read_text())['runs'][0]['configuration']
assert c==ref and c['input_routing']=='sparse' and c['base_size']==c['crop_size']==256
assert c['epochs']==300 and c['lr']==.05 and c['seed']==40
c['hf_enhancement']='signed_LH_times_HL_times_HH_then_DySample_conv_C_to_C'
job=dict(run_id='NUAA-SIRST_hf_triple_product_sparse_control300',group='hf_product_experiment',configuration=c)
save(E/'matrix.json',dict(runs=[job],reference='NUAA-SIRST_control300'))
for split in ['train','test']:
 p=R/'data/NUAA-SIRST/50_50'/(split+'.txt');assert sha(p)==baseline[split+'_ids_sha256']
source=(R/'artifacts/run_nuaa_fixed005_v2.py').read_text()
tree=ast.parse(source)
end=next(n.lineno for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='live_workers')-1
s='\n'.join(source.splitlines()[:end])+'\n'
s=s.replace("sys.path[:0]=[str(ROOT/'artifacts'),str(ROOT/'code/experiment_runtime')]", "EXP=ROOT/'artifacts/nuaa_hf_triple_product_v1'\nsys.path[:0]=[str(EXP/'support'),str(EXP/'runtime')]")
s=s.replace("ROOT/'runs/nuaa_fixed005_300'", "ROOT/'runs/nuaa_hf_triple_product_v1'")
start=s.index('def source_hashes():');stop=s.index('\ndef loaders(',start)
s=s[:start]+'''def source_hashes():
    paths=list((EXP/'runtime').rglob('*.py'))+list((EXP/'support').glob('*.py'))+[EXP/'runner.py',EXP/'matrix.json',EXP/'controller.py']
    return {str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
'''+s[stop:]
s=s.replace('loss.backward();opt.step()', "loss.backward();assert all(p.grad is None or torch.isfinite(p.grad).all() for p in net.parameters()), 'Nonfinite gradient';opt.step()")
# Metrics/evaluation/seed and data loading must be byte-equivalent at the AST level.
newtree=ast.parse(s)
for name in ['Metrics','evaluate','seed_all','loaders']:
 a=next(n for n in tree.body if getattr(n,'name',None)==name);b=next(n for n in newtree.body if getattr(n,'name',None)==name)
 assert ast.dump(a,include_attributes=False)==ast.dump(b,include_attributes=False),name
s+='''
def inspect_model(net):
    from model.mobile_mamba import MBWTConv2d
    from model.mask import SpatialSparseMoE
    hf=[(n,m) for n,m in net.named_modules() if isinstance(m,MBWTConv2d) and m.zone=='h']
    moe=[m for m in net.modules() if isinstance(m,SpatialSparseMoE)]
    assert len(hf)==len(moe)==15
    assert all(len(m.experts)==4 and m.input_routing=='sparse' for m in moe)
    assert all(m.hconv[0].offset.in_channels==m.in_channels//4 for _,m in hf)
    return hf

def extended_preflight(job):
    # Hook the actual four-step training preflight, checking raw product input and gradients.
    orig=build_model;records={};handles=[]
    def checked(c):
        net,notes=orig(c)
        for name,m in inspect_model(net):
            records[name]={'calls':0,'backward_calls':0,'nonzero_product':False,'nonzero_gradient':False}
            def capture(mod,inputs,n=name):
                x=inputs[0];bands=mod.wt_function(x)
                mod._product_expected=(bands[:,:,1]*bands[:,:,2]*bands[:,:,3]).detach()
            def verify(mod,inputs,n=name,parent=m):
                x=inputs[0];assert torch.isfinite(x).all()
                assert torch.equal(x,parent._product_expected)
                rec=records[n];rec['calls']+=1;rec['nonzero_product'] |= bool((x!=0).any())
                if x.requires_grad:
                    def gradcheck(g):
                        assert torch.isfinite(g).all(),'Nonfinite product gradient'
                        rec['backward_calls']+=1;rec['nonzero_gradient'] |= bool((g!=0).any())
                    x.register_hook(gradcheck)
            handles.append(m.register_forward_pre_hook(capture))
            handles.append(m.hconv.register_forward_pre_hook(verify))
        return net,notes
    globals()['build_model']=checked
    try:result=preflight(job)
    finally:
        globals()['build_model']=orig
        for h in handles:h.remove()
    assert all(v['calls']>=4 and v['backward_calls']>=4 and v['nonzero_product'] and v['nonzero_gradient'] for v in records.values())
    result['product_checks']=records;result['finite_parameter_gradients']=True
    return result

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--mode',choices=['preflight','run','cpu'],required=True);a=p.parse_args()
    job=json.loads((EXP/'matrix.json').read_text())['runs'][0]
    if a.mode=='preflight':atomic_json(EXP/'preflight.json',extended_preflight(job))
    elif a.mode=='cpu':
        net,notes=build_model(job['configuration']);hf=inspect_model(net)
        atomic_json(EXP/'cpu_check.json',dict(hf_modules=[n for n,m in hf],moe_count=15,experts_per_moe=4,input_routing='sparse',cuda_initialized=torch.cuda.is_initialized(),parameters=sum(p.numel() for p in net.parameters())))
    else:
        net,notes=build_model(job['configuration']);inspect_model(net);del net
        run(job)
'''
(E/'runner.py').write_text(s)
save(E/'setup_receipt.json',dict(job=job,reference_config=ref,train_ids_sha256=baseline['train_ids_sha256'],test_ids_sha256=baseline['test_ids_sha256'],runner_ast_verified=['Metrics','evaluate','seed_all','loaders'],change='HF enhancement concat(3C)->product(C), DySample C, convolution C->C; keep x + all-band IWT + enhancement',model_only_modified_file='runtime/model/mobile_mamba.py',original_files_unchanged=all(sha(R/k)==v for k,v in original.items())))
print('SETUP_OK',E,flush=True)
