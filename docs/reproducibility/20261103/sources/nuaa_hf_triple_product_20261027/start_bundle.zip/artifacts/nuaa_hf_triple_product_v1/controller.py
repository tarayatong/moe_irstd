from pathlib import Path
import os,json,time,hashlib,subprocess,sys,fcntl,traceback,zipfile,math
R=Path('/root/autodl-tmp/moe_reproduction');E=R/'artifacts/nuaa_hf_triple_product_v1';PY=R/'env/bin/python'
def atomic(p,obj):
 q=p.with_suffix('.tmp');q.write_text(json.dumps(obj,indent=2,allow_nan=False));q.replace(p)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def frozen():
 for k,v in json.loads((E/'contract.json').read_text()).items():assert sha(R/k)==v,k
 for k,v in json.loads((E/'original_source_hashes.json').read_text()).items():assert sha(R/k)==v,k
def resources():
 out=subprocess.check_output(['nvidia-smi','--query-gpu=memory.total,memory.free','--format=csv,noheader,nounits'],text=True).strip().split(',')
 apps=subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader,nounits'],text=True).strip()
 # This single new experiment starts only on an idle GPU; no existing task is touched.
 assert not apps, 'GPU already has compute processes: '+apps
 workers=[]
 for p in Path('/proc').iterdir():
  if p.name.isdigit():
   try:cmd=(p/'cmdline').read_bytes().replace(b'\0',b' ').decode()
   except (OSError,UnicodeDecodeError):continue
   if 'python' in cmd and ('--mode run' in cmd or '--mode preflight' in cmd):workers.append((p.name,cmd))
 assert not workers, str(workers)
 return dict(total_gib=float(out[0])/1024,free_gib=float(out[1])/1024)
def child(mode):
 with (E/(mode+'.log')).open('a') as f:
  p=subprocess.Popen([str(PY),str(E/'runner.py'),'--mode',mode],cwd=R,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
  atomic(E/'controller_status.json',dict(phase=mode,pid=os.getpid(),worker_pid=p.pid,updated=time.strftime('%Y-%m-%d %H:%M:%S')))
  return p.wait()
def audit():
 import torch
 torch.set_num_threads(1)
 job=json.loads((E/'matrix.json').read_text())['runs'][0];out=R/'runs/nuaa_hf_triple_product_v1'/job['run_id'];cfg=job['configuration']
 rows=[json.loads(l) for l in (out/'epochs.jsonl').read_text().splitlines() if l.strip()]
 best=torch.load(out/'best.pt',map_location='cpu',weights_only=False);last=torch.load(out/'last.pt',map_location='cpu',weights_only=False)
 m=json.loads((out/'manifest.json').read_text());status=json.loads((out/'status.json').read_text());bm=json.loads((out/'best_metrics.json').read_text())
 finite=lambda d: all(not isinstance(v,(float,int)) or math.isfinite(v) for v in d.values())
 checks=dict(complete=status['status']=='complete',epochs=len(rows)==300,sequence=[v['epoch'] for v in rows]==list(range(300)),finite_rows=all(finite(v) for v in rows),fixed_lr=all(v['lr']==v['next_lr']==.05 for v in rows),last_epoch=last['epoch']==299,config=m['job']==job and best['configuration']==cfg,best_same_epoch=best['epoch']==bm['epoch']==max(rows,key=lambda v:v['IoU'])['epoch'],best_metrics=all(best['metrics'][k]==bm[k]==rows[best['epoch']][k] for k in ['IoU','nIoU','Pd','Fa']),finite_weights=all(torch.isfinite(v).all().item() for w in [best['model'],last['model']] for v in w.values() if v.is_floating_point()),source=best['source_sha256']==last['source_sha256']==m['source_sha256'],config_hash=last['config_sha256']==m['config_sha256']==hashlib.sha256(json.dumps(cfg,sort_keys=True).encode()).hexdigest(),preflight=json.loads((E/'preflight.json').read_text())['status']=='passed',original_sources=True,contract=True)
 frozen()
 for split in ['train','test']:checks[split+'_split']=sha(R/'data/NUAA-SIRST/50_50'/(split+'.txt'))==m[split+'_ids_sha256']
 assert all(checks.values()),checks
 result=dict(run_id=job['run_id'],checks=checks,best_epoch_one_based=best['epoch']+1,metrics=best['metrics'],best_sha256=sha(out/'best.pt'),last_sha256=sha(out/'last.pt'),finished=status['finished'],selection='test highest IoU; one seed40 run')
 atomic(E/'completed_audit.json',result)
 archive=E/'NUAA_hf_triple_product_sparse_completed.zip'
 with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=5) as z:
  for p in out.iterdir():
   if p.is_file():z.write(p,str(p.relative_to(R)))
  for p in E.rglob('*'):
   if p.is_file() and p.suffix in ['.py','.json','.diff'] and '__pycache__' not in str(p) and p.name!='controller_status.json':z.write(p,str(p.relative_to(R)))
 atomic(E/'backup_receipt.json',dict(archive=str(archive),bytes=archive.stat().st_size,sha256=sha(archive),**result))
 return result
if __name__=='__main__':
 lock=(E/'controller.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 try:
  frozen();res=resources();assert res['free_gib']>22, 'Insufficient free capacity for initial preflight'
  assert child('preflight')==0, 'Preflight failed; training not started'
  frozen();pf=json.loads((E/'preflight.json').read_text());res=resources();reserve=pf['reserved_gib']*1.1+.5
  assert reserve<=min(res['free_gib'],res['total_gib'])-1.5, 'Measured memory reservation exceeds budget'
  atomic(E/'launch_receipt.json',dict(preflight_reserved_gib=pf['reserved_gib'],safety_reservation_gib=reserve,resources=res,started=time.strftime('%Y-%m-%d %H:%M:%S'),max_workers=2))
  assert child('run')==0,'Training worker failed'
  frozen();atomic(E/'controller_status.json',dict(phase='auditing',pid=os.getpid(),updated=time.strftime('%Y-%m-%d %H:%M:%S')))
  result=audit();atomic(E/'controller_status.json',dict(phase='complete_audited_remote',audit=result,updated=time.strftime('%Y-%m-%d %H:%M:%S')))
 except BaseException:
  atomic(E/'controller_status.json',dict(phase='error',traceback=traceback.format_exc(),updated=time.strftime('%Y-%m-%d %H:%M:%S')));raise
